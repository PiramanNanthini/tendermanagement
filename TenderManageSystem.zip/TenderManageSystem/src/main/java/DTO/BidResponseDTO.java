package DTO;

public class BidResponseDTO {
	private Long id;
	private Long tenderId;
    private String username;
    private String email;
    private double bidValue;
    private String status;

    public BidResponseDTO(String username, String email, double bidValue) {
        this.username = username;
        this.email = email;
        this.bidValue = bidValue;
    }
    
   

	public BidResponseDTO(Long id, Long tenderId, String username, String email, double bidValue, String status) {
		super();
		this.id = id;
		this.tenderId = tenderId;
		this.username = username;
		this.email = email;
		this.bidValue = bidValue;
		this.status = status;
	}



	public String getUsername() {
		return username;
	}

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getBidValue() {
		return bidValue;
	}

	public void setBidValue(double bidValue) {
		this.bidValue = bidValue;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getTenderId() {
		return tenderId;
	}



	public void setTenderId(Long tenderId) {
		this.tenderId = tenderId;
	}



	@Override
	public String toString() {
		return "BidResponseDTO [id=" + id + ", tenderId=" + tenderId + ", username=" + username + ", email=" + email
				+ ", bidValue=" + bidValue + ", status=" + status + "]";
	}



	public BidResponseDTO() {
		super();
		
	}

	
    
}
