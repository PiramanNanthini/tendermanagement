package com.nandhini.TenderManageSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nandhini.TenderManageSystem.entity.Tender;

import java.util.List;
import java.util.Optional;

public interface TenderRepository extends JpaRepository<Tender, Long> {

	List<Tender> findByEmail(String email);
	
	@Query("SELECT t FROM Tender t WHERE t.email <> :email")
	List<Tender> findAllExceptUserDocuments(String email);

	void save(Optional<Tender> tender);
   
}