package com.nandhini.TenderManageSystem.entity;

import jakarta.persistence.*;


@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	private String username;
    private String email;
    private String password;
//    @Lob
//    @Column(columnDefinition = "LONGBLOB") // Stores image as BLOB
//    private byte[] profilePicture;

   
	@Enumerated(EnumType.STRING)
    private Role role;
    
    public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public User(int id, String username, String email, String password, Role role) {
		super();
		this.id = id;
		this.username = username;
		this.email = email;
		this.password = password;
//		ProfilePicture = profilePicture;
		this.role = role;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	

		
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}
	
	
}

