package com.nandhini.TenderManageSystem.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nandhini.TenderManageSystem.entity.Bid;
import com.nandhini.TenderManageSystem.entity.Role;
import com.nandhini.TenderManageSystem.entity.User;
import com.nandhini.TenderManageSystem.repository.BidRepository;
import com.nandhini.TenderManageSystem.repository.UserRepository;

import DTO.BidResponseDTO;

@Service
public class AuthService {
	
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private BidRepository bidRepository;
    

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public String registerUser(User user) {
    	System.out.println("userservice: "+user);
        Optional<User> existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser.isPresent()) {
        	System.err.println("email existed");
            return "Email already registered";
        }

      
        user.setPassword(passwordEncoder.encode(user.getPassword()));

      
        if (user.getRole() == null) {
            user.setRole(Role.VENDOR);  
        }

        userRepository.save(user);
        return "User registered successfully!";
    }
    
    public User login(String email, String password) throws Exception {
      
        User user = userRepository.findByEmail(email).orElseThrow(() -> new Exception("Email not exist"));

       
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new Exception("Password wrong");
        }

        return user; 
    }

    
	public List<BidResponseDTO> getBidResponses(long tenderId) {
		 List<Bid> bids = bidRepository.findByTenderId(tenderId);
		 System.err.println("bids testinggggg: maroiiiiiiiiiiii");
		 System.out.println("bids testinggggg: "+ bids);
	        List<BidResponseDTO> bidResponses = bids.stream().map(bid -> {
	            Optional<User> user = userRepository.findByEmail(bid.getEmail());
	            return new BidResponseDTO(bid.getId(),bid.getTenderId(), user.get().getUsername(), user.get().getEmail(), bid.getBidValue(),bid.getStatus());
	        }).collect(Collectors.toList());
	        
	        return bidResponses;
		 
	}
	
	
	public List<BidResponseDTO> getMyBidResponses(long id, String email) {
	    List<Bid> bids = bidRepository.findByTenderId(id)
	                                  .stream()
	                                  .filter(bid -> bid.getEmail().equals(email))
	                                  .collect(Collectors.toList());

	    return bids.stream().map(bid -> {
	        Optional<User> user = userRepository.findByEmail(bid.getEmail());
	        return user.map(value -> new BidResponseDTO(bid.getId(),bid.getTenderId(), user.get().getUsername(), user.get().getEmail(), bid.getBidValue(),bid.getStatus()))
	                   .orElse(null);
	    }).filter(Objects::nonNull).collect(Collectors.toList());
	}


	public User updateUserProfile(String email, String username, String profilePicture) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setUsername(username);

            return userRepository.save(user); 
        }
        throw new RuntimeException("User not found");
    }
}