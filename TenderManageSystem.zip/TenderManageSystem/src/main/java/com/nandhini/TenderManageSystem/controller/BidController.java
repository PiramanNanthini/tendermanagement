package com.nandhini.TenderManageSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.nandhini.TenderManageSystem.entity.Bid;
import com.nandhini.TenderManageSystem.entity.Tender;
import com.nandhini.TenderManageSystem.entity.User;
import com.nandhini.TenderManageSystem.service.AuthService;
import com.nandhini.TenderManageSystem.service.BidService;

import DTO.BidResponseDTO;
import DTO.BidStatusUpdateRequest;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/bids")
@CrossOrigin(origins = "*")
public class BidController {

    @Autowired
    private BidService bidService;
    
    
    @Autowired
    private AuthService authService;

    @PostMapping("/placeBid")
    public Bid placeBid(@RequestBody Bid bidRequest) {
        return bidService.placeBid(bidRequest.getTenderId(), bidRequest.getEmail(), bidRequest.getBidValue());
    }

    @GetMapping("/getBids/{tenderId}")
    public List<Bid> getBids(@PathVariable Long tenderId) {
        return bidService.getBidsByTenderId(tenderId);
    }
    
    @GetMapping("/getBiders/{tenderId}")
    public ResponseEntity<List<BidResponseDTO>> getBidsByTenderId(@PathVariable long tenderId) {
      
        List<BidResponseDTO> bidResponses = authService.getBidResponses(tenderId);
        
        return ResponseEntity.ok(bidResponses);
    }
    
    @GetMapping("/getMyBidsByTenderId")
    public ResponseEntity<List<BidResponseDTO>> getMyBidsByTenderId(@RequestParam long id, @RequestParam String email) {
      
        List<BidResponseDTO> bidResponses = authService.getMyBidResponses(id, email);
        
        return ResponseEntity.ok(bidResponses);
    }
    
    @GetMapping("/getTendersByEmail")
    public List<Tender> getTendersByEmail(@RequestParam String email) {
        return bidService.getTendersByUserEmail(email);
    }

    @PutMapping("/updateBidStatus")
    public ResponseEntity<String> updateBidStatus(@RequestParam long bidId, @RequestParam String status, @RequestParam Long tenderId) {
       
        
        System.out.println("bidId "+bidId);
        System.out.println("status "+status);

        if (bidId == 0 || status == null) {
            return ResponseEntity.badRequest().body("Missing bidId or status");
        }

        boolean updated = bidService.updateBidStatus(bidId, status, tenderId);
        if (updated) {
            return ResponseEntity.ok("Bid status updated successfully");
        } else {
            return ResponseEntity.status(404).body("Bid not found");
        }
    }

}
