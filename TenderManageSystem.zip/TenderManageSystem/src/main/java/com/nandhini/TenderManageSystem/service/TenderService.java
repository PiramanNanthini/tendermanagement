package com.nandhini.TenderManageSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nandhini.TenderManageSystem.entity.Tender;
import com.nandhini.TenderManageSystem.entity.User;
import com.nandhini.TenderManageSystem.repository.TenderRepository;
import com.nandhini.TenderManageSystem.repository.UserRepository;

@Service
public class TenderService {

	@Autowired
    private TenderRepository tenderRepository;
	
	@Autowired
    private UserRepository userRepository;

    
	public List<Tender> getAllTenders(String email) {
        return tenderRepository.findAllExceptUserDocuments(email);
    }

   
    public Tender createTender(Tender tender) {
    	String email = tender.getEmail();
    	
    	 Optional<User> user = userRepository.findByEmail(email);
    	    
    	    if (user.isPresent()) {
    	    	User currentUser = user.get();
    	        tender.setUser(currentUser); 
    	    }
        return tenderRepository.save(tender);
    }
    
    public void deleteTender(Long id) {
        tenderRepository.deleteById(id);
    }
    
    public List<Tender> getTenderByEmail(String email) {
        return tenderRepository.findByEmail(email);
    }


	
}
