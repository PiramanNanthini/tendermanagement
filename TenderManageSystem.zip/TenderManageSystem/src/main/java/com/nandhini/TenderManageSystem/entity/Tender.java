package com.nandhini.TenderManageSystem.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "tenders")
public class Tender {
   
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user; 

    
    public Tender(Long id, String name, String email, String description, int bids, double minBid, LocalDate endDate,
			String allocateEmail, User user) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.description = description;
		this.bids = bids;
		this.minBid = minBid;
		this.endDate = endDate;
		this.allocateEmail = allocateEmail;
		this.user = user;
	}

	public String getAllocateEmail() {
		return allocateEmail;
	}

	public void setAllocateEmail(String allocateEmail) {
		this.allocateEmail = allocateEmail;
	}

	public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getBids() {
		return bids;
	}
	public void setBids(int bids) {
		this.bids = bids;
	}
	public double getMinBid() {
		return minBid;
	}
	public void setMinBid(double minBid) {
		this.minBid = minBid;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public Tender(Long id, String name, String email, String description, int bids, double minBid, LocalDate endDate) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.description = description;
		this.bids = bids;
		this.minBid = minBid;
		this.endDate = endDate;
	}
	public Tender() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String name;
	    private String email;
	    @Column(columnDefinition = "TEXT")
	    private String description;
	    private int bids;
	    private double minBid;
	    private LocalDate endDate;
	    private String allocateEmail;

	
       
}