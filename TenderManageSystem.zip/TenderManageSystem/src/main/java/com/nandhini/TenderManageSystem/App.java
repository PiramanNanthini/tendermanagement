package com.nandhini.TenderManageSystem;


import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

@SpringBootApplication (exclude = { SecurityAutoConfiguration.class })
public class App {
    public static void main(String[] args) {
    	System.out.println("am started....................");
        SpringApplication.run(App.class, args);
        System.out.println("am finished...................");
//    	ArrayList <String> employees = new ArrayList<String>();
//    	employees.add("mari");
//    	employees.add("durai");
//    	employees.add("virat");
//    	employees.add("kophliiiiiiiiiiiii");
//    	employees.add("karthick");
//    	employees.add("rajaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
//    	
//    	List sortedEmp = employees.stream().filter(emp -> emp.length()>10).collect(Collectors.toList());
//    	System.out.println("sortedEmp"+sortedEmp);
    	
    }
}