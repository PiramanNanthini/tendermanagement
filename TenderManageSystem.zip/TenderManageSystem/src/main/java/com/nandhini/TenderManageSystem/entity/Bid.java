package com.nandhini.TenderManageSystem.entity;

import jakarta.persistence.*;

@Entity
public class Bid {

	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long tenderId;
    private String email;
    private Double bidValue;
    private String status;
    

    public Bid() {
		super();
		
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Long getTenderId() {
		return tenderId;
	}


	public void setTenderId(Long tenderId) {
		this.tenderId = tenderId;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Double getBidValue() {
		return bidValue;
	}


	public void setBidValue(Double bidValue) {
		this.bidValue = bidValue;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Bid(Long id, Long tenderId, String email, Double bidValue, String status) {
		super();
		this.id = id;
		this.tenderId = tenderId;
		this.email = email;
		this.bidValue = bidValue;
		this.status = status;
	}


	@Override
	public String toString() {
		return "Bid [id=" + id + ", tenderId=" + tenderId + ", email=" + email + ", bidValue=" + bidValue + ", status="
				+ status + "]";
	}
    
    
}

