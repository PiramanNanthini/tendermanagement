package com.nandhini.TenderManageSystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nandhini.TenderManageSystem.entity.Bid;
import com.nandhini.TenderManageSystem.entity.Tender;
import com.nandhini.TenderManageSystem.repository.BidRepository;
import com.nandhini.TenderManageSystem.repository.TenderRepository;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class BidService {

    @Autowired
    private BidRepository bidRepository;
    
    @Autowired
    private TenderRepository tenderRepository;
    
    public Bid placeBid(Long tenderId, String email, Double bidValue) {
        
    	 Bid bid = new Bid();
         bid.setTenderId(tenderId);
         bid.setEmail(email);
         bid.setBidValue(bidValue);
         bid.setStatus("pending"); //pending, accept, reject
         
        Optional<Tender> tender = tenderRepository.findById(tenderId);
        int bidCounts=tender.get().getBids();
        if(tender.isPresent()) {
        	Tender tender2 = tender.get();
        	 tender2.setBids(bidCounts + 1);
        	 tenderRepository.save(tender2);
        }
       
        return bidRepository.save(bid);
    }

    public List<Bid> getBidsByTenderId(Long tenderId) {
        return bidRepository.findByTenderId(tenderId);
    }
    
    public List<Tender> getTendersByUserEmail(String email) {
        List<Bid> bids = bidRepository.findByEmail(email);

        if (bids.isEmpty()) {
            return Collections.emptyList();
        }

        Set<Long> tenderIds = bids.stream()
                                  .map(bid -> bid.getTenderId())
                                  .collect(Collectors.toSet());

        
        return tenderRepository.findAllById(tenderIds);
    }
    
    public boolean updateBidStatus(Long bidId, String status, Long tenderId) {
        Optional<Bid> optionalBid = bidRepository.findById(bidId);
        System.err.println(status );
    	System.err.println(bidId );
    	System.err.println(tenderId );
    	System.err.println(status=="accept" );
    	System.err.println(status.equals("accept"));
        if(status.equals("accept")) {
        	System.err.println("status is accept" );
        	System.err.println(status );
        	System.err.println(bidId );
        	System.err.println(tenderId );
        Optional<Tender> tender = tenderRepository.findById(tenderId);
        
        if(tender.isPresent()) {
        	Tender tender2 = tender.get();
        	 tender2.setAllocateEmail(optionalBid.get().getEmail() );
        	 tenderRepository.save(tender2);
        }
        }
        
        if (optionalBid.isPresent()) {
            Bid bid = optionalBid.get();
            
            bid.setStatus(status);
            bidRepository.save(bid);
            return true;
        }
        return false;
    }


}
