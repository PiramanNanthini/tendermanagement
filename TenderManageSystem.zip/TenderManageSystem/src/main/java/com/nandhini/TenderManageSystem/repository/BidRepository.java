package com.nandhini.TenderManageSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nandhini.TenderManageSystem.entity.Bid;

import java.util.List;

public interface BidRepository extends JpaRepository<Bid, Long> {
    List<Bid> findByTenderId(Long tenderId);

	List<Bid> findByEmail(String email);
}
