package com.nandhini.TenderManageSystem.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.nandhini.TenderManageSystem.entity.User;
import com.nandhini.TenderManageSystem.service.AuthService;

@RestController
@RequestMapping("/auth")
public class AuthController {
	
    @Autowired
    private AuthService authService;

    @PostMapping("/signup")
    public ResponseEntity<?> signUp(@RequestBody User user) {
    	
        String message = authService.registerUser(user);
        if (message.equals("User registered successfully!")) {
            return ResponseEntity.ok(message);
        }
        System.err.println("message: "+message);
        return ResponseEntity.badRequest().body(message);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginRequest) {
        try {
           
            User user = authService.login(loginRequest.getEmail(), loginRequest.getPassword());
            return ResponseEntity.ok(user);
        } catch (Exception e) {
         
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }
    
}