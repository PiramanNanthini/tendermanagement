import React, { useEffect, useState } from "react";
import api from "../ConfigurationComponents/apiConfig";
import "./Dashboard.css";

const BiddingPopup = ({ tender, onClose }) => {
  const [highestBid, setHighestBid] = useState(null);
  const [bidValue, setBidValue] = useState("");
  const [error, setError] = useState("");
  const [userIsHighestBidder, setUserIsHighestBidder] = useState(false);
  const [token, setToken] = useState("");

  useEffect(() => {
    const tokens = localStorage.getItem("Token");
    setToken(tokens);
    
    if (tender.bids > 0) {
      fetchBids(tokens);
    }
  }, [tender]);

  const fetchBids = async (tokens) => {
    try {
      const response = await api.get(`/bids/getAllBids/${tender.id}`);
      const bids = response.data;
      console.log("bidssssss: ",bids)
      if (bids.length > 0) {
        const highest = bids.reduce((prev, curr) => 
          parseFloat(prev.bidValue) > parseFloat(curr.bidValue) ? prev : curr
        );

        setHighestBid(highest);
        setUserIsHighestBidder(highest.email === tokens);
      }
    } catch (error) {
      console.error("Error fetching bids:", error);
    }
  };

  const handleConfirmBid = async () => {
    if (!bidValue || isNaN(bidValue)) {
      setError("Please enter a valid bid amount");
      return;
    }

    const minValue = highestBid ? highestBid.bidValue : tender.minBid;

    if (parseFloat(bidValue) <= parseFloat(minValue)) {
      setError(`Bid value should be greater than ₹${minValue}`);
      return;
    }

    try {
      await api.post("/bids/placeBid", { tenderId: tender.id, bidValue, email: token });
      onClose();
    } catch (error) {
      console.error("Error placing bid:", error);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-box">
        <h3 className="modal-title">Place Your Bid</h3>
        {tender.bids === 0 ? (
          <p>Bid amount should be more than the minimum bid value ₹{tender.minBid}</p>
        ) : userIsHighestBidder ? (
          <p>You are the highest bidder! Your bid: ₹{highestBid?.bidValue}</p>
        ) : (
          <p>Highest bid value: ₹{highestBid?.bidValue || "-"}</p>
        )}

        {!userIsHighestBidder && (
          <>
            <input
              type="number"
              placeholder="Enter your bid"
              value={bidValue}
              onChange={(e) => setBidValue(e.target.value)}
            />
            {error && <p className="error-text">{error}</p>}
            <button onClick={handleConfirmBid} className="confirm-button">Confirm Bid</button>
          </>
        )}
        <button onClick={onClose} className="cancel-button">Cancel</button>
      </div>
    </div>
  );
};

export default BiddingPopup;




























// import React, { useEffect, useState } from "react";
// import api from "../ConfigurationComponents/apiConfig";
// import { FaGavel } from "react-icons/fa";
// import "./Dashboard.css";

// const BiddingPopup = ({ tender, onClose }) => {
//   const [highestBid, setHighestBid] = useState(null);
//   const [bidValue, setBidValue] = useState("");
//   const [error, setError] = useState("");
//   const [userIsHighestBidder, setUserIsHighestBidder] = useState(false);
//   const [token, setToken] = useState("");
//    //  const token = localStorage.getItem("Token");

//   useEffect(() => {
//      const tokens = localStorage.getItem("Token");
//      setToken(tokens)
//      console.log("token: ", token )
//     if (tender.bids > 0) {
//       fetchBids();
//     }
//   }, [tender]);

//   const fetchBids = async () => {
//     try {
//       const response = await api.get(`/bids/getAllBids/${tender.id}`);
//       const bids = response.data;
//       if (bids.length > 0) {
//         const highest = bids.reduce((prev, curr) => (prev.bidValue > curr.bidValue ? prev : curr));
//         setHighestBid(highest);
//         setUserIsHighestBidder(highest.email === token);
//       }
//     } catch (error) {
//       console.error("Error fetching bids:", error);
//     }
//   };

//   const handleConfirmBid = async () => {
//     const minValue = tender.bids > 0 ? highestBid.bidValue : tender.minBid;
//     if (parseFloat(bidValue) <= minValue) {
//       setError(`Bid value should be greater than ${minValue}`);
//       return;
//     }
//     try {
//       await api.post("/bids/placeBid", { tenderId: tender.id, bidValue, email:token });
//       onClose();
//     } catch (error) {
//       console.error("Error placing bid:", error);
//     }
//   };

//   return (
//     <div className="modal-overlay">
//       <div className="modal-box">
//         <h3 className="modal-title">Place Your Bid</h3>
//         {tender.bids === 0 ? (
//           <p>Bid amount should be more than the minimum bid value ₹{tender.minBid}</p>
//         ) : userIsHighestBidder ? (
//           <p>You are the highest bidder till now! Your bid: ₹{highestBid.bidValue}</p>
//         ) : (
//           <p>Highest bid value is ₹{highestBid?.bidValue || "-"}</p>
//         )}
//         {!userIsHighestBidder && (
//           <>
//             <input
//               type="number"
//               placeholder="Enter your bid"
//               value={bidValue}
//               onChange={(e) => setBidValue(e.target.value)}
//             />
//             {error && <p className="error-text">{error}</p>}
//             <button onClick={handleConfirmBid} className="confirm-button">Confirm Bid</button>
//           </>
//         )}
//         <button onClick={onClose} className="cancel-button">Cancel</button>
//       </div>
//     </div>
//   );
// };

// export default BiddingPopup;
