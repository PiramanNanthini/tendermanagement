import React, { useEffect, useState } from "react";
import "./BiddingPopup.css"; 

const BiddingPopupMyBids = ({ bids, onClose }) => {

  useEffect(() => {
  
  
    console.log("hello mybids: ",bids)
  }, []);

  return (
    <div className="modal-overlay">
      <div className="modal-box">
        <h3 className="modal-title">My Bids</h3>
        {bids.length === 0 ? (
          <p>No bids available for this tender</p>
        ) : (
          <table className="bidding-table">
            <thead>
              <tr>
                <th>Username</th>
                <th>Bid Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {bids.map((bid, index) => (
                <tr key={index}>
                  <td>{bid.username}</td>
                  <td>₹{bid.bidValue}</td>
                  <td>{bid.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <button onClick={onClose} className="cancel-button">Close</button>
      </div>
    </div>
  );
};

export default BiddingPopupMyBids;
