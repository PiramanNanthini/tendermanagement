import React, { useState } from "react";
import api from "../ConfigurationComponents/apiConfig";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const CreateTender = () => {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    minBid: "",
    endDate: "",
    email:localStorage.getItem('Token')
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log('endDate:',formData.endDate)
    try {
      const response = await api.post("/tender/createTender", formData);
      if (response) {
        toast.success("🎉 Tender Created Successfully!", {
          position: "top-right",
          autoClose: 3000,
        });
        setFormData({ name: "", description: "", minBid: "", endDate: "" });
      }
    } catch (error) {
      toast.error("❌ Error creating tender. Try again!");
    }
  };

  return (
    <div className="container">
      <ToastContainer />
      <div className="form-box">
        {/* <h2 style={styles.title}>Create New Tender</h2> */}

        <form onSubmit={handleSubmit} className="form">
          <input
            type="text"
            name="name"
            placeholder="Tender Name"
            value={formData.name}
            onChange={handleChange}
            required
            className="inside-input"
          />

          <textarea
            name="description"
            placeholder="Tender Description"
            value={formData.description}
            onChange={handleChange}
            required
            rows="3"
            className="inside-input"
          ></textarea>

          <input
            type="number"
            name="minBid"
            placeholder="Minimum Bid Value"
            value={formData.minBid}
            onChange={handleChange}
            required
            className="inside-input"
          />

        {/* <label htmlFor="endDate" style={{ fontSize: "14px", color: "#666" }}>
          Last Date to Bid (dd-mm-yyyy)
        </label> */}
          <input
            type="date"
            name="endDate"
            placeholder="Last Date to Bid (dd-mm-yyyy)"
            value={formData.endDate}
            onChange={handleChange}
            required
            className="inside-input"
          />

          <button type="submit" className="create-tender-button">
            Create Tender
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreateTender;

const styles={
  title:{
    padding:'10px',
    paddingLeft:'40px'
  }
}

