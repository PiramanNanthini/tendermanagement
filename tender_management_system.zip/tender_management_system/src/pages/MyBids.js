import React, { useEffect, useState } from "react";
import api from "../ConfigurationComponents/apiConfig";
import "./Dashboard.css";
import BiddingPopupMyBids from "./BiddingPopupMyBids";

const MyBids = () => {
  const [tenders, setTenders] = useState([]);
  const [showBiddingPopup, setShowBiddingPopup] = useState(false);
  const [selectedTender, setSelectedTender] = useState(null);
  const [bids, setBids] = useState([]); // Store bid values
  const email = localStorage.getItem("Token");
  useEffect(() => {
    const fetchTenders = async () => {
      try {
       
        if (!email) {
          console.error("User email not found in localStorage");
          return;
        }
  
        // Call the new API that fetches tenders directly
        const response = await api.get(`/bids/getTendersByEmail?email=${email}`);
        setTenders(response.data);
  
      } catch (error) {
        console.error("Error fetching tenders:", error);
      }
    };
  
    fetchTenders();
  }, []);

  const fetchBidsByTender = async (tenderId) => {
    try {
      const response = await api.get(`/bids/getMyBidsByTenderId?id=${tenderId}&email=${email}`);
      setBids(response.data); 
      setShowBiddingPopup(true);
    } catch (error) {
      console.error("Error fetching bids for tender:", error);
    }
  };

  return (
    <div className="tender-list">
      {tenders.map((tender) => (
        <div className="tender-card" key={tender.id}>
          <div className="profileBar">
            <div className="profile-image-section">
              <img
                src={"/images/default-image.jpg"}
                alt="User"
                className="profile-image"
              />
            </div>
            <div>
              <h2 className="user-name">{tender.user.username}</h2>
            </div>
          </div>

          <h3 className="tender-title">{tender.name}</h3>
          <p className="tender-description">{tender.description}</p>

          <div className="tender-details">
            <div className="tender-info">
              <span className="info-label">Number of Bids:</span>
              <span className="info-value">{tender.bids} ⚖️</span>
            </div>

            <div className="tender-info">
              <span className="info-label">Minimum Bid Value:</span>
              <span className="info-value"> ₹{tender.minBid}</span>
            </div>

            <div className="tender-info">
              <span className="info-label">Last Bid Date:</span>
              <span className="info-value"> {tender.endDate}</span>
            </div>

            <button
              className="bid-button"
              onClick={() => {
                setSelectedTender(tender);
                fetchBidsByTender(tender.id);
              }}
            >
              My Bids
            </button>
          </div>
        </div>
      ))}

      {showBiddingPopup && selectedTender && (
        <BiddingPopupMyBids
          tender={selectedTender}
          bids={bids}
          onClose={() => setShowBiddingPopup(false)}
        />
      )}
    </div>
  );
};

export default MyBids;
