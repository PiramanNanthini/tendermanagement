import React, { useState } from "react";
import { FaBars, FaTachometerAlt, FaPlus, FaFileAlt, FaGavel, FaSignOutAlt } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import './Home.css';
import Dashboard from "./Dashboard";
import CreateTender from "./CreateTender";
import MyBids from "./MyBids";
import MyTenders from "./MyTenders";


const Home = () => {
  const [activeScreen, setActiveScreen] = useState("Dashboard");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const navigate = useNavigate(); 
  const username = localStorage.getItem('userName')

  const menuItems = [
    { name: "Dashboard", icon: <FaTachometerAlt size={30} /> },
    { name: "Create Tender", icon: <FaPlus size={30} /> },
    { name: "My Tenders", icon: <FaFileAlt size={30} /> },
    { name: "My Bids", icon: <FaGavel size={30} /> },
    { name: "Log out", icon: <FaSignOutAlt size={30} /> },
  ];

  const handleLogout = async () => {
   
    localStorage.removeItem('Token');
    // navigate("/login");
     window.location.reload();  
  };

  return (
    <div className="home-container">
  
      <div className={`sidebar ${isSidebarOpen ? "open" : ""}`}>
    
        <button className="toggle-btn" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
          {isSidebarOpen ? (
            <>
              &#8592;
              <span className="toggle-text">E - Procurement</span>
            </>
          ) : (
            <FaBars className="toggle-icon" />
          )}
        </button>

        <ul>
          {menuItems.map((item) => (
            <li
              key={item.name}
              className={activeScreen === item.name ? "active" : ""}
              onClick={() => {
                if (item.name === "Log out") {
                  handleLogout(); 
                } else {
                  setActiveScreen(item.name);
                }
              }}
            >
              {item.icon} {isSidebarOpen && <span>{item.name}</span>}
            </li>
          ))}
        </ul>
      </div>

  
      <div className="main-content">
    
      <div   className="topbar">
       
      <h1>{isSidebarOpen ? activeScreen : `E - Procurement - ${activeScreen}`}</h1>

        {/* <div className="profile-image-section" onClick={() => setIsPopupOpen(true)}> */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <img src={"/images/default-image.jpg"} alt="User" className="profile-image" />
               
                <h3>{username}</h3>
             </div>
      </div>

          {activeScreen === "Dashboard" && <Dashboard />}
          {activeScreen === "Create Tender" && <CreateTender />}
          {activeScreen === "My Tenders" && <MyTenders/>}
          {activeScreen === "My Bids" && <MyBids/>}
        </div>
      </div>
  );
};

export default Home;













