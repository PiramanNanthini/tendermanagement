import React, { useEffect, useState, useRef } from "react";
import api from "../ConfigurationComponents/apiConfig";
import { FaGavel, FaTrash } from "react-icons/fa";
import { toast } from "react-toastify";
import BiddingPopup2 from "./BiddingPopup2";
import "./Dashboard.css";

const MyTenders = () => {
  const [tenders, setTenders] = useState([]);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showBidsModal, setShowBidsModal] = useState(false);
  const [selectedTenderId, setSelectedTenderId] = useState(null);
  const refreshRef = useRef(null);
  const [bids, setBids] = useState([]);


const fetchBids = async (tenderId) => {
  try {
    const response = await api.get(`/bids/getBiders/${tenderId}`);
    console.log("table bids: ",response.data)
    setBids(response.data);
    setShowBidsModal(true);
  } catch (error) {
    console.error("Error fetching bids:", error);
  }
};


  useEffect(() => {  
    fetchTenders();
  }, []);

  const fetchTenders = async () => {
    try {
      const token = localStorage.getItem('Token');
      const response = await api.get(`/tender/getMyTenders/${token}`);
      setTenders(response.data);
      console.log("response.data",response.data)
      console.log("tenders",tenders)
    } catch (error) {
      console.error("Error fetching tenders:", error);
    }
  };

  const confirmDelete = async () => {
    setShowDeleteModal(false);
    try {
        console.log("selectedTenderId",selectedTenderId)
      await api.delete(`/tender/deleteTender/${selectedTenderId}`);
      toast.success("Tender deleted successfully!");
      fetchTenders();
    } catch (error) {
      console.error("Error deleting tender:", error);
      toast.error("Failed to delete tender");
    }
  };

  return (
    <div className="tender-list">
      {tenders.map((tender) => (
        <div className="tender-card" key={tender.id}>
          <h3 className="tender-title">{tender.name}</h3>
          <p className="tender-description">{tender.description}</p>
          <div className="tender-details">
            <div className="tender-info">
              <span className="info-label">Number of Bids:</span>
              <span className="info-value">{tender.bids} ⚖️</span>
            </div>
            <div className="tender-info">
              <span className="info-label">Minimum Bid Value:</span>
              <span className="info-value"> ₹{tender.minBid}</span>
            </div>
            <div className="tender-info">
              <span className="info-label">Last Bid Date:</span>
              <span className="info-value"> {tender.endDate}</span>
            </div>
            <button className="bid-button" onClick={() => fetchBids(tender.id)}>
              <FaGavel className="bid-icon" /> Check Bids
            </button>

            <button className="delete-button" onClick={() => {
                setSelectedTenderId(tender.id);
                setShowDeleteModal(true);
              }} style={{
                backgroundColor: "#e63946",
                color: "#fff",
                padding: "8px 16px",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                fontWeight: "bold",
                boxShadow: "0 2px 5px rgba(0,0,0,0.2)",
                transition: "background-color 0.3s ease",
              }}
              onMouseOver={(e) => (e.target.style.backgroundColor = "#d62828")}
              onMouseOut={(e) => (e.target.style.backgroundColor = "#e63946")}
            >
              <FaTrash className="delete-icon" /> Delete
            </button>
          </div>
        </div>
      ))}

{showBidsModal && <BiddingPopup2 bids={bids} onClose={() => setShowBidsModal(false)} />}

       {showDeleteModal && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h3 className="modal-title">Confirm Deletion</h3>
            <p>Are you sure you want to delete this tender?</p>
            <div className="modal-actions" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <button onClick={confirmDelete} className="confirm-button">
                Confirm
              </button>
              <button onClick={() => setShowDeleteModal(false)} className="cancel-button" style={{ marginBottom:"15px"}}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>

    
  );
};

export default MyTenders;

