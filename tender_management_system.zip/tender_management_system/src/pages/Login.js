import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../ConfigurationComponents/apiConfig";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css"; 

const Login = () => {
 
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const validateForm = () => {
    let newErrors = {};
    let isValid = true;

    if (!form.email.trim()) {
      newErrors.email = "Email is required.";
      isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = "Invalid email format.";
      isValid = false;
    }

    if (form.password.length < 1 ) {
      newErrors.password = "Password required";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError("");

    if (!validateForm()) return;

    try {
      console.log('form: ',form)
      const response = await api.post('/auth/login', form);
      const user = response.data;
      if (response.status === 200) {
        localStorage.setItem('userName', user.username)
        localStorage.setItem('Token', form.email);
        toast.success("LoggedIn successfully!", {
          position: "top-center",
          autoClose: 2000, 
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          theme: "dark",
        });

        setTimeout(() => {
          navigate("/home");
        }, 3000);
      }
    } catch (error) {
      console.error("Error during LoggedIn:", error); 
    
      console.log(error.response.data)
        if (error.response.data.includes("Email not exist")) {
          setErrors({ ...errors, email: "User not exist" });
        }else if(error.response.data.includes("Password wrong")){
          setErrors({ ...errors, password: "Incorrect Password" });
        } else {
          setServerError("Something went wrong. Please try again1.");
        }
      } 
    }
    
    
  

  return (
    <div style={styles.container}>
  <div style={styles.imageContainer}>
    <img src="/images/heroBanner2.png" alt="Banner" style={styles.image} />
  </div>

  <div style={styles.rightContainer}>
  
 
   <div style={styles.formContainer}>
    <form onSubmit={handleSubmit}>

   
    <h2 style={styles.heading}>E - Procurement</h2>
    {serverError && <p className="error-message">{serverError}</p>}

              <div>
              {errors.email && <p className="error-message">{errors.email}</p>}
              <input 
                type="email" 
                name="email" 
                placeholder="Email" 
                className="input" 
                value={form.email} 
                onChange={handleChange}
              />
              </div>

              <div>
              {errors.password && <p className="error-message">{errors.password}</p>}
              <input 
                type="password" 
                name="password" 
                placeholder="Password" 
                className="input" 
                value={form.password} 
                onChange={handleChange}
              />
            </div>
              
              <button className="button" type="submit">
                Sign In
              </button>

              <p className="login-text">
              Don't have an account? <Link to="/">Sign Up</Link>
            </p>
            </form>
            </div> 
  </div>
  </div>
      
  );
};

export default Login;


document.styleSheets[0].insertRule(`
  .formContainer::-webkit-scrollbar {
    display: none;
  }
`, 0);

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'stretch',
    justifyContent: 'center',
    width: '100vw',
    height: '100vh',
    background: 'linear-gradient(135deg, #202040, #3a3a55)',
    borderRadius: '0px',
    boxShadow: 'none',
    overflow: 'hidden', 
    animation: 'fadeIn 0.5s ease-in-out'
  },

  formContainer: {
    width: "100%",
    height: "80%",
    paddingLeft: '20px',
    paddingRight: '20px',
    overflowY: "scroll", 
    scrollbarWidth: "none", 
    msOverflowStyle: "none", 
  },
  
  imageContainer: {
    width: '70%',  
    height: '100vh',  
    display: 'flex',
    justifyContent: 'center',  
    alignItems: 'center', 
    overflow: 'hidden',  
  },
  
  image: {
    width: '100%', 
    height: '100%',
    margin:'130px',
    objectFit: 'cover', 
  },
  
  rightContainer: {
    width: '30vw',
    height: '80vh',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '50px',
    background: 'rgba(255, 255, 255, 0.1)', 
    backdropFilter: 'blur(15px)',
    borderRadius: '12px',
    boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.2)',
    overflow: 'hidden',
    margin: '5vh 2vw 5vh 2vw' 
  },
  heading: {
    fontFamily: "'Montserrat', sans-serif",
    fontSize: '38px',
    fontWeight: 'bold',
    textAlign: 'center',
    // marginBottom: '20px',
    //  padding:'20px',
    color: '#ffffff', 
  //  textTransform: 'uppercase',
    letterSpacing: '1px',
  },
}
























