import React, { useEffect, useState } from "react";
import api from "../ConfigurationComponents/apiConfig";
import { FaGavel } from "react-icons/fa";
import "./Dashboard.css";
import BiddingPopup from "./BiddingPopup";


const Dashboard = () => {
  const [tenders, setTenders] = useState([]);
  const [showBiddingPopup, setShowBiddingPopup] = useState(false);
  const [selectedTender, setSelectedTender] = useState(null);

  
useEffect(() => {
    const fetchTenders = async () => {
      try {
        const token = localStorage.getItem("Token");
        const response = await api.get(`/tender/getAllTenders?email=${token}`);
        console.log("dashboard tenders: ",response.data)
        setTenders(response.data);
      } catch (error) {
        console.error("Error fetching tenders:", error);
      }
    };
  
    fetchTenders();
  }, []);
  

  return (

      <div className="tender-list">
        {tenders.map((tender) => (
          <div className="tender-card" key={tender.id}>
            
            <div className="profileBar">
              <div  style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <div className="profile-image-section">
                    <img src={"/images/default-image.jpg"}  alt="User" className="profile-image" />
                </div>
                  <div>
                      <h2 className="user-name">{tender.user.username}</h2>
                  </div>
              </div>

              <div>
  {tender.allocateEmail && (
    <p>
      <span style={{ fontWeight: "bold", marginRight: "5px" }}>Allocated to:</span>
      <span style={{ fontSize: "14px", color: "#888", fontWeight: "500", paddingRight: "10px" }}>
      🎉{tender.allocateEmail}
      </span>
    </p>
  )}
</div>
                
             </div>





           


            
            <h3 className="tender-title">{tender.name}</h3>
            <p className="tender-description">{tender.description}</p>
            
            <div className="tender-details">
              <div className="tender-info">
                <span className="info-label">Number of Bids:</span>
                <span className="info-value">{tender.bids} ⚖️</span>
              </div>
              
              <div className="tender-info">
                <span className="info-label">Minimum Bid Value:</span>
                <span className="info-value"> ₹{tender.minBid}</span>
              </div>

              <div className="tender-info">
                <span className="info-label">Last Bid Date:</span>
                <span className="info-value"> {tender.endDate}</span>
              </div>
              
              {!tender.allocateEmail && <button
              className="bid-button"
              onClick={() => {
                setSelectedTender(tender);
                setShowBiddingPopup(true);
              }}
            >
              <FaGavel className="bid-icon" /> Place Bid
            </button>}
            </div>
          </div>
        ))}

      {showBiddingPopup && selectedTender && (
        <BiddingPopup tender={selectedTender} onClose={() => setShowBiddingPopup(false)} />
      )}

      </div>
    
  );
};

export default Dashboard;








// <div className="profileBar" style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
// <div className="profile-image-section" style={{ display: "flex", alignItems: "center" }}>
//   <img src={"/images/default-image.jpg"} alt="User" className="profile-image" />
//   <h2 className="user-name" style={{ marginLeft: "10px" }}>{tender.user.username}</h2>
// </div>

// {tender.allocateEmail && (
//   <span style={{ fontSize: "14px", color: "#666", fontWeight: "500" }}>
//     Allocated to: {tender.allocateEmail}
//   </span>
// )}
// </div>