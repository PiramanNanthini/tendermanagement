import React, { useState, useEffect } from "react";
import "./BiddingPopup.css";
import api from "../ConfigurationComponents/apiConfig";

const BiddingPopup2 = ({ bids, onClose }) => {
  const [bidStatuses, setBidStatuses] = useState([]);
  const [confirmIndex, setConfirmIndex] = useState(null); // index for confirm popup
  const [actionStatus, setActionStatus] = useState(""); // 'accept', 'reject', etc.
  const [hasAcceptedBid, setHasAcceptedBid] = useState(false); // 🆕 track if any status is accept

  useEffect(() => {
    const initialStatuses = bids.map((bid) => bid.status || "pending");
    setBidStatuses(initialStatuses);
    setActionStatus(
      initialStatuses.includes("accept")
        ? "accept"
        : initialStatuses.includes("reject")
        ? "reject"
        : "pending"
    );
    setHasAcceptedBid(initialStatuses.includes("accept")); // 🆕 update this
  }, [bids]);

  const updateStatus = async (index, newStatus) => {
    const bid = bids[index];
    try {
      const response = await api.put(
        `/bids/updateBidStatus?bidId=${bid.id}&status=${newStatus}&tenderId=${bid.tenderId}`
      );

      if (response.status === 200) {
        const updated = [...bidStatuses];
        updated[index] = newStatus;
        setBidStatuses(updated);
        setHasAcceptedBid(updated.includes("accept")); // 🆕 re-check after update
        onClose(); // Close popup after success
      } else {
        console.error("Failed to update status");
      }
    } catch (error) {
      console.error("Error updating bid:", error);
    }
  };

  const renderActions = (status, index) => {
    if (actionStatus === "accept") {
      return status === "accept" ? (
        <>
          <button
            className="pending-button"
            onClick={() => updateStatus(index, "pending")}
          >
            pending
          </button>
          <button
            className="reject-button"
            onClick={() => updateStatus(index, "reject")}
          >
            Reject
          </button>
        </>
      ) : null;
    } else if (actionStatus === "reject") {
      return (
        <>
          <button
            className="accept-button"
            onClick={() => updateStatus(index, "accept")}
            disabled={status === "accept"}
          >
            Accept
          </button>
          {status === "reject" ? (
            <button
              className="pending-button"
              onClick={() => updateStatus(index, "pending")}
            >
              pending
            </button>
          ) : (
            <button
              className="reject-button"
              onClick={() => updateStatus(index, "reject")}
              disabled={status === "reject"}
            >
              Reject
            </button>
          )}
        </>
      );
    } else {
      return (
        <>
          <button
            className="accept-button"
            onClick={() => updateStatus(index, "accept")}
            disabled={status !== "pending"}
          >
            Accept
          </button>
          <button
            className="reject-button"
            onClick={() => updateStatus(index, "reject")}
            disabled={status !== "pending"}
          >
            Reject
          </button>
        </>
      );
    }
  };

  return (
    <div className="overlay">
      <div className="box">
        <h3 className="modal-title">Bidding Details</h3>
        {bids.length === 0 ? (
          <p>No bids available for this tender.</p>
        ) : (
          <table className="bidding-table">
            <thead>
              <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Bid Amount</th>
                <th>Status</th>
                <th>Actions</th>
                {hasAcceptedBid && <th>Payment</th>} {/* 🆕 Only show column if needed */}
              </tr>
            </thead>
            <tbody>
              {bids.map((bid, index) => (
                <tr key={bid.id}>
                  <td>{bid.username}</td>
                  <td>{bid.email}</td>
                  <td>₹{bid.bidValue}</td>
                  <td>{bidStatuses[index]}</td>
                  <td>{renderActions(bidStatuses[index], index)}</td>
                  {hasAcceptedBid && (
                    <td>
                      {bidStatuses[index] === "accept" && (
                        <>
                          <button
                            className="payment-button"
                            onClick={() => alert("Payment Successful")}
                          >
                            Payment
                          </button>
                          <button
                            className="email-button"
                            onClick={() =>
                              (window.location.href = `mailto:${bid.email}`)
                            }
                          >
                            Email
                          </button>
                        </>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <button onClick={onClose} className="cancel-button">
          Close
        </button>

        {confirmIndex !== null && (
          <div className="confirm-popup">
            <div className="confirm-box">
              <p>Confirm accept this bid?</p>
              <div className="confirm-actions">
                <button
                  className="yes-button"
                  onClick={() => updateStatus(confirmIndex, "accept")}
                >
                  Yes
                </button>
                <button
                  className="no-button"
                  onClick={() => setConfirmIndex(null)}
                >
                  No
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BiddingPopup2;













// import React, { useState, useEffect } from "react";
// import "./BiddingPopup.css";
// import api from "../ConfigurationComponents/apiConfig";

// const BiddingPopup2 = ({ bids, onClose }) => {
//   const [bidStatuses, setBidStatuses] = useState([]);
//   const [confirmIndex, setConfirmIndex] = useState(null); // index for confirm popup
//   const [actionStatus, setActionStatus] = useState(""); // 'accept', 'reject', etc.

//   useEffect(() => {
//     console.log("bidsInitial: ", bids);
//     const initialStatuses = bids.map((bid) => bid.status || "pending");
//     setBidStatuses(initialStatuses);
//     setActionStatus(
//       initialStatuses.includes("accept")
//         ? "accept"
//         : initialStatuses.includes("reject")
//         ? "reject"
//         : "pending"
//     );
//   }, [bids]);

//   const updateStatus = async (index, newStatus) => {
//     const bid = bids[index];
//     console.log("bidindexxxxxxxxxxxx: ", index);
//     console.log("bidindexxxxxxxxxxxx: ", newStatus);
//     console.log("bidindexxxxxxxxxxxx: ", bid);
//     console.log("bidindexxxxxxxxxxxx: ", bid.id);
//     try {
//       const response = await api.put(
//         `/bids/updateBidStatus?bidId=${bid.id}&status=${newStatus}&tenderId=${bid.tenderId}`
//       );

//       if (response.status === 200) {
//         const updated = [...bidStatuses];
//         updated[index] = newStatus;
//         setBidStatuses(updated);
//         onClose(); // Close popup after success
//       } else {
//         console.error("Failed to update status");
//       }
//     } catch (error) {
//       console.error("Error updating bid:", error);
//     }
//   };

//   const renderActions = (status, index) => {
//     console.log("indexxxxxxxxxxxx: ", index);
//     console.log("indexxxxxxxxxxxx: ", status);
//     if (actionStatus === "accept") {
//       // Only show buttons for accept record
//       return status === "accept" ? (
//         <>
//           <button
//             className="pending-button"
//             onClick={() => updateStatus(index, "pending")}
//           >
//             pending
//           </button>
//           <button
//             className="reject-button"
//             onClick={() => updateStatus(index, "reject")}
//           >
//             Reject
//           </button>
//         </>
//       ) : null;
//     } else if (actionStatus === "reject") {
//       return (
//         <>
//           <button
//             className="accept-button"
//             onClick={() => updateStatus(index, "accept")}
//             disabled={status === "accept"}
//           >
//             Accept
//           </button>
//           {status === "reject" ? (
//             <button
//               className="pending-button"
//               onClick={() => updateStatus(index, "pending")}
//             >
//               pending
//             </button>
//           ) : (
//             <button
//               className="reject-button"
//               onClick={() => updateStatus(index, "reject")}
//               disabled={status === "reject"}
//             >
//               Reject
//             </button>
//           )}
//         </>
//       );
//     } else {
//       return (
//         <>
//           <button
//             className="accept-button"
//             onClick={() => updateStatus(index, "accept")}
//             disabled={status !== "pending"}
//           >
//             Accept
//           </button>
//           <button
//             className="reject-button"
//             onClick={() => updateStatus(index, "reject")}
//             disabled={status !== "pending"}
//           >
//             Reject
//           </button>
//         </>
//       );
//     }
//   };

//   return (
//     <div className="modal-overlay">
//       <div className="modal-box">
//         <h3 className="modal-title">Bidding Details</h3>
//         {bids.length === 0 ? (
//           <p>No bids available for this tender.</p>
//         ) : (
//           <table className="bidding-table">
//             <thead>
//               <tr>
//                 <th>Username</th>
//                 <th>Email</th>
//                 <th>Bid Amount</th>
//                 <th>Status</th>
//                 <th>Actions</th>
//                 <th>Payment</th> {/* ✅ New column header */}
//               </tr>
//             </thead>
//             <tbody>
//               {bids.map((bid, index) => (
//                 <tr key={bid.id}>
//                   <td>{bid.username}</td>
//                   <td>{bid.email}</td>
//                   <td>₹{bid.bidValue}</td>
//                   <td>{bidStatuses[index]}</td>
//                   <td>{renderActions(bidStatuses[index], index)}</td>
//                   <td>
//                     {bidStatuses[index] === "accept" && (
//                       <>
//                         <button
//                           className="payment-button"
//                           onClick={() => alert("Payment Successful")}
//                         >
//                           Payment
//                         </button>
//                         <button
//                           className="email-button"
//                           onClick={() =>
//                             (window.location.href = `mailto:${bid.email}`)
//                           }
//                         >
//                           Email
//                         </button>
//                       </>
//                     )}
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         )}
//         <button onClick={onClose} className="cancel-button">
//           Close
//         </button>

//         {/* Confirmation Popup (if you still need it) */}
//         {confirmIndex !== null && (
//           <div className="confirm-popup">
//             <div className="confirm-box">
//               <p>Confirm accept this bid?</p>
//               <div className="confirm-actions">
//                 <button
//                   className="yes-button"
//                   onClick={() => updateStatus(confirmIndex, "accept")}
//                 >
//                   Yes
//                 </button>
//                 <button
//                   className="no-button"
//                   onClick={() => setConfirmIndex(null)}
//                 >
//                   No
//                 </button>
//               </div>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default BiddingPopup2;




























// import React from "react";
// import "./BiddingPopup.css"; 

// const BiddingPopup2 = ({ bids, onClose }) => {
//   return (
//     <div className="modal-overlay">
//       <div className="modal-box">
//         <h3 className="modal-title">Bidding Details</h3>
//         {bids.length === 0 ? (
//           <p>No bids available for this tender.</p>
//         ) : (
//           <table className="bidding-table">
//             <thead>
//               <tr>
//                 <th>Username</th>
//                 <th>Email</th>
//                 <th>Bid Amount</th>
//               </tr>
//             </thead>
//             <tbody>
//               {bids.map((bid, index) => (
//                 <tr key={index}>
//                   <td>{bid.username}</td>
//                   <td>{bid.email}</td>
//                   <td>₹{bid.bidValue}</td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         )}
//         <button onClick={onClose} className="cancel-button">Close</button>
//       </div>
//     </div>
//   );
// };

// export default BiddingPopup2;
