import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../ConfigurationComponents/apiConfig";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const SignUp = () => {
 
  const navigate = useNavigate();

  const [form, setForm] = useState({
    role: "vendor", 
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" }); 
  };

  const validateForm = () => {
    let newErrors = {};
    let isValid = true;

    if (!form.username.trim()) {
      newErrors.username = "Username is required.";
      isValid = false;
    }

    if (!form.email.trim()) {
      newErrors.email = "Email is required.";
      isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = "Invalid email format.";
      isValid = false;
    }

    if (form.password.length < 8 || form.password.length > 16) {
      newErrors.password = "Password must be 8-16 characters.";
      isValid = false;
    }

    if (form.password !== form.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerError("");

    if (!validateForm()) return;

    try {
      console.log('form: ',form)
      const response = await api.post('/auth/signup', form);

      if (response.status === 200) {
        toast.success("Account created successfully!", {
          position: "top-center",
          autoClose: 2000, 
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          theme: "dark",
        });

        setTimeout(() => {
          navigate("/login");
        }, 3000);
      }
    } catch (error) {
      console.error("Error during signup:", error);
    
      console.log(error.response.data)
        if (error.response.data.includes("Email already registered")) {
          setErrors({ ...errors, email: "Email is already registered." });
        } else {
          setServerError("Something went wrong. Please try again1.");
        }
      } 
    }
    
    
  

  return (
    <div style={styles.container}>
  <div style={styles.imageContainer}>
    <img src="/images/heroBanner.png" alt="Banner" style={styles.image} />
  </div>

  <div style={styles.rightContainer}>
  
  <h2 style={styles.heading}>E - Procurement</h2>
  <div style={styles.formContainer}>
    <form onSubmit={handleSubmit}>

   

    {serverError && <p className="error-message">{serverError}</p>}
            <div className="dropdown-container">
            <select 
              type="role" 
              name="role" 
              className="dropdown" 
              value={form.role} 
              onChange={handleChange}
            >
              <option value="vendor">Vendor</option>
              <option value="client">Client</option>
            </select>
          </div>

    <div>
          {errors.username && <p className="error-message">{errors.username}</p>}
              <input 
                type="text" 
                name="username" 
                placeholder="Username" 
                className="input" 
                value={form.username} 
                onChange={handleChange}
              />
              </div>

              <div>
              {errors.email && <p className="error-message">{errors.email}</p>}
              <input 
                type="email" 
                name="email" 
                placeholder="Email" 
                className="input" 
                value={form.email} 
                onChange={handleChange}
              />
              </div>

              <div>
              {errors.password && <p className="error-message">{errors.password}</p>}
              <input 
                type="password" 
                name="password" 
                placeholder="Password" 
                className="input" 
                value={form.password} 
                onChange={handleChange}
              />
            </div>

            <div>
            {errors.confirmPassword && <p className="error-message">{errors.confirmPassword}</p>}
              <input 
                type="password" 
                name="confirmPassword" 
                placeholder="Confirm Password" 
                className="input" 
                value={form.confirmPassword} 
                onChange={handleChange}
              />
                </div>
              
              <button className="button" type="submit">
                Sign Up
              </button>

              <p className="login-text">
              Already have an account? <Link to="/login">Login</Link>
            </p>
            </form>
            </div> 
  </div>
  </div>
      
  );
};

export default SignUp;

document.styleSheets[0].insertRule(`
  .formContainer::-webkit-scrollbar {
    display: none;
  }
`, 0);

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'stretch',
    justifyContent: 'center',
    width: '100vw',
    height: '100vh',
    background: 'linear-gradient(135deg, #202040, #3a3a55)',
    borderRadius: '0px',
    boxShadow: 'none',
    overflow: 'hidden',  
    animation: 'fadeIn 0.5s ease-in-out'
  },

  formContainer: {
    width: "100%",
    height: "100%",
    paddingLeft: '20px',
    paddingRight: '20px',
    overflowY: "scroll",
    scrollbarWidth: "none", 
    msOverflowStyle: "none", 
  },
  
  imageContainer: {
    width: '70%',  
    height: '100vh', 
    display: 'flex',
    justifyContent: 'center',  
    alignItems: 'center', 
    overflow: 'hidden',  
  },
  
  image: {
    width: '100%', 
    height: '100%', 
    margin:'130px',
    objectFit: 'cover', 
  },
  
  rightContainer: {
    width: '30vw',
    height: '80vh', 
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '50px',
    background: 'rgba(255, 255, 255, 0.1)', 
    backdropFilter: 'blur(15px)',
    borderRadius: '12px',
    boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.2)',
    overflow: 'hidden',
    margin: '5vh 2vw 5vh 2vw'
  },
  heading: {
    fontFamily: "'Montserrat', sans-serif",
    fontSize: '38px',
    fontWeight: 'bold',
    textAlign: 'center',
    // marginBottom: '20px',
    //  padding:'20px',
    color: '#ffffff', 
  //  textTransform: 'uppercase',
    letterSpacing: '1px',
  },
}



