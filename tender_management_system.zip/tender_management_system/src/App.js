import React, { useEffect, useState } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import Login from './pages/Login';
import Home from './pages/Home';
import CreateTender from './pages/CreateTender';
import Dashboard from './pages/Dashboard';
import SignUp from './pages/SignUp';
import MyTenders from './pages/MyTenders';

function App() {
  const navigate = useNavigate();
  const [initialRoute, setInitialRoute] = useState("/");

  useEffect(() => {
    const checkToken = async () => {
      try {
        const token = localStorage.getItem('Token');
        if (token) {
          setInitialRoute("/home");
          navigate("/home"); 
        } else {
          setInitialRoute("/");
          navigate("/");
        }
      } catch (error) {
        console.error("Error fetching token:", error);
      }
    };

    checkToken();
  }, []);

  return (
    <div className="app">
      <ToastContainer />
      <Routes>
        <Route path="/" element={<SignUp />} />
        <Route path="/login" element={<Login />} />
        <Route path="/home" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/createTender" element={<CreateTender />} /> 
        <Route path="/MyTenders" element={<MyTenders />} />
      </Routes>
    </div>
  );
}

export default App;




















